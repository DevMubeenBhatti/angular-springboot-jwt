package com.spring.security.spingbootjwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpingbootjwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
