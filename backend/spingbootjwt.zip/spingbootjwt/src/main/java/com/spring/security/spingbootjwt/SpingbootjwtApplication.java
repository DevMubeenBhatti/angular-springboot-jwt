package com.spring.security.spingbootjwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpingbootjwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpingbootjwtApplication.class, args);
	}

}
